import Home  from '../components/Home.vue'
import Services from '../components/services/index.vue'
import Hero from '../components/hero/index.vue'
import WatchVideo from '../components/watch/index.vue'
import Contact from '../components/contact/index.vue'
import Works from '../components/lastWork/page.vue'
import Clients from '../components/clients/index.vue'
import Page from '../components/page/index.vue'
import Blog from '../components/blog/index.vue'
import Work from '../components/lastWork/work.vue'
import Contact2 from '../components/page/page.vue'


export default {
    mode : "history" , 

    scrollBehavior(to, from, savedPosition) {
        if (savedPosition) {
          return savedPosition
        } 
          return { x: 0, y: 0 }
        
      },
    routes : [
        {
            path: '/',
            component : Home ,
            name : 'home',
            meta: {
                title: 'الرئيسية',
            }
        },

        {
            path: '/campny',
            component : Home ,
            name : 'campny',
            meta: {
                title: 'الرئيسية',
            },
        },

        
        {
            path: '/home/works',
            component : Works ,
            name : 'works',
            meta: {
                title: 'المشاريع',
            }
        },
        {
            path: '/home/services',
            component : Services ,
            name : 'services',
            meta: {
                title: 'الخدمات',
            }
        },

        {
            path: '/home/hero',
            component : Hero ,
            name : 'hero',
            meta: {
                title: 'الاحصائيات',
            }
        },
        {
            path: '/home/watch',
            component : WatchVideo ,
            name : 'watch',
            meta: {
                title: 'شاهد الان',
            }
        },

        {
            path: '/home/contact',
            component : Contact ,
            name : 'contact',
            meta: {
                title: 'اتصل بنا',
            }
        },

        {
            path: '/home/clients',
            component : Clients ,
            name : 'clients',
            meta: {
                title: ' العملاء',
            }
        },

        {
            path: '/home/contact',
            component : Contact ,
            name : 'campnycontact',
            meta: {
                title: 'اتصل بنا ',
            }
        },


        {
            path: '/home/works',
            component : Works ,
            name : 'works1',
            meta: {
                title: 'المشاريع',
            }
        },
        {
            path: '/home/services',
            component : Services ,
            name : 'services1',
            meta: {
                title: 'الخدمات',
            }
        },

        {
            path: '/home/page/:id',
            component : Page ,
            name : 'page',
            
        },

        {
            path: '/home/contact2/:id',
            component : Contact2 ,
            name : 'contact2',
            
        },

        

        {
            path: '/home/work/:id',
            component : Work ,
            name : 'work',
            
        },


        
        {
            path: '/home/blog',
            component : Blog ,
            name : 'blog',
            meta: {
                title: 'الصفحات',
            }
        },
         

        
    ]
}