<template>
<div>

<section class="section watch-video is-clearfix">
              <div class="container">
                <br>
                <br>
                <div class="columns is-variable is-8 is-multiline">
                  <div class="column is-6-desktop is-12-tablet" data-aos="fade">
                    <br>
                    <h1 class="heading-title style-1 has-text-left">تصميم يساعد فى نمو عملك.</h1>
                    <p>هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف.</p>
                    <br>
                    <div class="works-button">
                      <a href="./pages/about.html" class="button is-primary is-rounded">اقرأ المزيد</a>
                    </div>
                    <!-- .works-button -->
                  </div>
                  <div class="column is-6-desktop is-12-tablet has-text-centered" data-aos="fade-up">
                    <div class="works-latest">
                      <div class="works-latest-item">
                        <img alt="Joo - Niche Multi-Purpose HTML Template" src="assets/images/global/introduction.png">
                        <div class="works-latest-item-icon style-2">
                          <a href="https://www.youtube.com/watch?v=N3qo_13jWAc" class="mfp-lightbox mfp-iframe">
                            <span class="icon ripple-effect">
                              <i class="ion-ios-play"></i>
                            </span>
                          </a>
                        </div>
                        <!-- .works-latest-icon -->
                      </div>
                      <!-- .works-latest-item -->
                    </div>
                  </div>
                </div>
                <br> </div>
            </section>
</div>
</template>

<script>
    export default {
        mounted() {
            console.log('Component mounted.')
        }
    }
</script>
