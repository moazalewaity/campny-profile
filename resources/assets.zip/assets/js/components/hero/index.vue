<template>
<div>

<section class="hero fun-facts has-text-centered is-clearfix">
              <div class="hero-body">
                <div class="container">
                  <h2 class="display-none">funfacts</h2>
                  <nav class="level counterup with-icons">
                    <div class="level-item has-text-centered">
                      <div>
                        <span class="icon ">
                          <i class="icon-wallet"></i>
                        </span>
                        <p class="title counter">70</p>
                        <p class="heading">جائزة عالمية</p>
                      </div>
                    </div>
                    <div class="level-item has-text-centered">
                      <div>
                        <span class="icon ">
                          <i class="icon-cup"></i>
                        </span>
                        <p class="title counter">30</p>
                        <p class="heading">عميل للشركة</p>
                      </div>
                    </div>
                    <div class="level-item has-text-centered">
                      <div>
                        <span class="icon ">
                          <i class="icon-heart"></i>
                        </span>
                        <p class="title counter">4</p>
                        <p class="heading">شركة ناشئة</p>
                      </div>
                    </div>
                    <div class="level-item has-text-centered">
                      <div>
                        <span class="icon ">
                          <i class="icon-rocket"></i>
                        </span>
                        <p class="title counter">24/12</p>
                        <p class="heading">ساعات العمل</p>
                      </div>
                    </div>
                  </nav>
                  <!-- .counterup -->
                </div>
              </div>
            </section>

</div>
</template>

<script>
    export default {
        mounted() {
            // console.log('Component mounted.')
        }
    }
</script>
