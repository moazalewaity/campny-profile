export default {
    state : {
        title : "Forum with laravel 6 & vue js (SPA)"
    },
    getters:{
        showTitle(state){
           return  state.title
        }
    }
}