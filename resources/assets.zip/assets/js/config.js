export const API_BASE_URL = 'https://www.wathiq.om/api';

// export const API_BASE_URL = 'http://3asef.club/campny/api';

export const API_BASE_URL_local = 'http://localhost:8000/api';

export const LANG = document.getElementsByTagName('html')[0].getAttribute('lang');

// export let LANG = ()=>{
//     setInterval(function(){
        
//         document.getElementsByTagName('html')[0].getAttribute('lang')

//         }, 3000);
// }


